
  # ازياء قرطبة

  This is a code bundle for ازياء قرطبة. The original project is available at https://www.figma.com/design/knfTb4sE2UPSAXEr0AmvAR/%D8%A7%D8%B2%D9%8A%D8%A7%D8%A1-%D9%82%D8%B1%D8%B7%D8%A8%D8%A9.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  